# DevOps Practical Exam Kit — Quick Revision

This repository contains simple answers and runnable files for the five DevOps practical question sets:
Git, Node.js, Docker, GitHub, and Jenkins.

## Before the practical
- Open Command Prompt / PowerShell in this folder.
- Install Node.js and Git; make sure Docker Desktop is running.
- Jenkins tasks require a working Jenkins installation, commonly `http://localhost:8080`.
- Replace `YOUR-USERNAME` and the GitHub repository URL with your own details.
- Do not commit passwords, tokens, or private credentials.

---

# SET 1

## Q1. Initialize Git, create README.md, and commit

```bash
git init
git branch -M main
git status
git add README.md
git commit -m "Add README"
git log --oneline
```

If README.md does not exist, create it first. If Git asks for identity, configure your own details:

```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

## Q2. Create a Hello World Node.js app

The runnable app is in `server.js`.

```bash
node server.js
```

Open `http://localhost:3000`. Expected browser output: `Hello World!`.
Stop the server with `Ctrl+C`.

### Explain the code
- `require('http')` imports Node.js's built-in HTTP module.
- `http.createServer(...)` creates a web server.
- `res.end('Hello World!')` sends the response to the browser.
- `server.listen(3000, ...)` starts listening on port 3000.

## Q3. Steps to run the app locally
1. Open a terminal in the project folder.
2. Run `node server.js`.
3. Wait for `Server running on port 3000`.
4. Open `http://localhost:3000` in a browser.
5. Stop with `Ctrl+C`.

---

# SET 2 — Docker

## Q1. Dockerfile and instructions

The `Dockerfile` in this repository is:

```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY server.js .
EXPOSE 3000
CMD ["node", "server.js"]
```

- `FROM`: selects the base Node.js image.
- `WORKDIR`: sets the working directory inside the image.
- `COPY`: copies `server.js` into the image.
- `EXPOSE`: documents the application's container port.
- `CMD`: command that runs when the container starts.

## Q2. Build an image and list images

Run in the folder containing Dockerfile:

```bash
docker build -t hello-app .
docker images
```

`-t hello-app` gives the image a name; `.` means use the current folder as build context.

## Q3. Run a container and access it in a browser

```bash
docker run -d --name hello-container -p 3000:3000 hello-app
docker ps
```

Open `http://localhost:3000`.

Port mapping is `HOST_PORT:CONTAINER_PORT`. For host port 8080 instead:

```bash
docker run -d --name hello-container -p 8080:3000 hello-app
```

Then open `http://localhost:8080`.

### Useful Docker commands

```bash
docker ps
docker ps -a
docker images
docker logs hello-container
docker stop hello-container
docker start hello-container
docker rm -f hello-container
docker rmi hello-app
```

If the container name already exists, run `docker rm -f hello-container` before creating it again. If port 3000 is busy, use `-p 3001:3000` and open `http://localhost:3001`. After changing code, rebuild the image and recreate the container.

---

# SET 3 — Git branches and GitHub

## Q1. Create and verify `feature-app`

```bash
git switch -c feature-app
git branch
```

The `*` marks the current branch. If your Git version does not support `git switch`, use `git checkout -b feature-app`.

## Q2. Connect the local project to GitHub and push

1. Create a **new empty repository** on GitHub. If you already have a local README, do not initialize the GitHub repository with another README.
2. Copy its HTTPS URL.
3. Run these commands, replacing the URL:

```bash
git remote add origin https://github.com/YOUR-USERNAME/devops-practical-exam-kit.git
git push -u origin main
```

Verify the remote:

```bash
git remote -v
git branch -a
```

If `origin` already exists, use:

```bash
git remote set-url origin https://github.com/YOUR-USERNAME/devops-practical-exam-kit.git
git push -u origin main
```

Push a feature branch:

```bash
git push -u origin feature-app
```

## Q3. Run Docker and access the app

```bash
docker build -t hello-app .
docker run -d --name hello-container -p 3000:3000 hello-app
docker ps
```

Open `http://localhost:3000`.

---

# SET 4 — Feature branch and Jenkins

## Q1. Create a branch, change output, commit and push

```bash
git switch main
git switch -c feature-update
```

Edit `server.js` and change:

```javascript
res.end('Hello World!');
```

to:

```javascript
res.end('Hello from feature-update!');
```

Then run:

```bash
git add server.js
git commit -m "Update application message"
git push -u origin feature-update
```

## Q2. Create Dockerfile, build image, list images

Use the `Dockerfile` in this repository:

```bash
docker build -t hello-app .
docker images
```

## Q3. Create a Jenkins Pipeline job

1. Open `http://localhost:8080` and sign in.
2. Select **New Item**.
3. Enter `HelloWorld-Pipeline`.
4. Select **Pipeline**, then **OK**.
5. In the Pipeline section, select **Pipeline script** and paste:

```groovy
pipeline {
    agent any
    stages {
        stage('Hello') {
            steps {
                echo 'Hello World from Jenkins'
            }
        }
    }
}
```

6. Save → **Build Now** → open **Console Output**.
7. Expected output includes `Hello World from Jenkins` and `Finished: SUCCESS`.

---

# SET 5 — Merge and CI/CD pipeline

## Q1. Merge `feature-app` into main and push

```bash
git switch main
git merge feature-app
git log --oneline --graph --all
git push origin main
```

If there is a merge conflict, edit the file to resolve conflict markers, save, then:

```bash
git add .
git commit -m "Resolve merge conflict"
git push origin main
```

## Q2. Configure Jenkins to pull source from GitHub

1. Commit and push `Jenkinsfile` to your GitHub repository.
2. In Jenkins, create/open a Pipeline job and click **Configure**.
3. Under **Pipeline**, choose **Pipeline script from SCM**.
4. SCM: **Git**.
5. Repository URL: your repository HTTPS URL.
6. Branch specifier: `*/main`.
7. Script Path: `Jenkinsfile`.
8. Save and run the build.

For a private repository, configure credentials in Jenkins. Never put passwords or access tokens directly in a Jenkinsfile.

## Q3. Jenkins pipeline to clone, build image, and run container

This `Jenkinsfile` is for a **Windows Jenkins agent** where Git, Docker CLI, and Docker daemon access are already configured:

```groovy
pipeline {
    agent any

    stages {
        stage('Clone') {
            steps {
                checkout scm
            }
        }

        stage('Build') {
            steps {
                bat 'docker build -t hello-app .'
            }
        }

        stage('Run') {
            steps {
                bat 'docker rm -f hello-container 2>NUL || exit /b 0'
                bat 'docker run -d --name hello-container -p 3000:3000 hello-app'
            }
        }

        stage('Verify') {
            steps {
                bat 'docker ps'
            }
        }
    }
}
```

For a Linux Jenkins agent, use `sh` steps instead of `bat`. Jenkins running inside a container does not automatically have access to the host Docker daemon; the lab environment must be configured for that. After a successful run, open `http://localhost:3000` on the machine where the container port is published.

---

# Common viva questions — short answers

1. **What is Git?** A distributed version control system used to track changes in files.
2. **What is GitHub?** An online platform to host Git repositories and collaborate.
3. **What is a repository?** A project location where files and their version history are stored.
4. **What is a commit?** A saved snapshot of staged changes.
5. **What is a branch?** An independent line of development.
6. **What is merging?** Combining changes from one branch into another.
7. **What is Node.js?** A JavaScript runtime that runs JavaScript outside the browser.
8. **What is Docker?** A platform for packaging and running applications in containers.
9. **What is a Docker image?** A template used to create containers.
10. **What is a container?** A running isolated instance created from an image.
11. **What is a Dockerfile?** A text file containing instructions to build an image.
12. **What is port mapping?** Connecting a host port to a container port, such as `-p 3000:3000`.
13. **What is Jenkins?** An automation server used for building, testing, and deploying software.
14. **What is a pipeline?** A series of automated stages such as clone, build, test, and deploy.
15. **What is CI/CD?** Continuous Integration and Continuous Delivery/Deployment, automating software integration and release steps.

# Quick command revision

```bash
git init
git status
git add .
git commit -m "Initial commit"
git branch
git switch -c feature-app
git switch main
git merge feature-app
git remote -v
git push -u origin main
node server.js
docker build -t hello-app .
docker images
docker run -d --name hello-container -p 3000:3000 hello-app
docker ps
docker logs hello-container
```

**Exam tip:** Read the question carefully and perform only the requested steps. Replace example GitHub URLs with your own. Do not share account passwords or tokens.
